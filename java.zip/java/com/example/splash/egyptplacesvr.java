package com.example.splash;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class egyptplacesvr extends AppCompatActivity {
     Button btn,clr;
     WebView pyramids;
     WebView Luxor;
     EditText txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_egyptplacesvr);
        btn=(Button)findViewById(R.id.landmarlsrch);
        clr=(Button)findViewById(R.id.clear);
        pyramids=(WebView)findViewById(R.id.pyramids);
        Luxor=(WebView)findViewById(R.id.cairotower);
        txt=(EditText)findViewById(R.id.vrsearch);


        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pyramids.setVisibility(View.INVISIBLE);
                Luxor.setVisibility(View.INVISIBLE);
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=txt.getText().toString().trim();
                if(s.equals("pyramids")){
                    pyramids.setWebViewClient(new WebViewClient());
                    pyramids.getSettings().setJavaScriptEnabled(true);
                    pyramids.loadUrl("https://www.airpano.com/vtour_mobile/egypt-cairo-pyramids/");
                    pyramids.setVisibility(View.VISIBLE);

                }
                else if(s.equals("Luxor")){

                    Luxor.setWebViewClient(new WebViewClient());
                    Luxor.getSettings().setJavaScriptEnabled(true);
                    Luxor.loadUrl("https://www.airpano.com/vtour_mobile/luxor-egypt/");
                    Luxor.setVisibility(View.VISIBLE);

                }
                else {
                    Toast.makeText(egyptplacesvr.this, "Can't find the item you're searching for", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}