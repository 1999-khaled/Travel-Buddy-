package com.example.splash.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import com.example.splash.R;
import com.example.splash.egypthotels;
import com.example.splash.egyptplacesvr;
import com.example.splash.egyptrestaurants;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class TAB1EA extends Fragment {
    WebView webView;
    Button vr;
    Button hotels;
    Button rest;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab1ea,container,false);
        webView=(WebView)v.findViewById(R.id.webview);
        hotels=(Button)v.findViewById(R.id.hotels);
        rest=(Button)v.findViewById(R.id.rest);
        vr=(Button)v.findViewById(R.id.landmarkvr);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.worldometers.info/coronavirus/country/egypt/");

        vr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), egyptplacesvr.class));
            }
        });

        hotels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), egypthotels.class);
                startActivity(i);
            }
        });
        rest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), egyptrestaurants.class);
                startActivity(i);
            }
        });

        return v;
    }
}
