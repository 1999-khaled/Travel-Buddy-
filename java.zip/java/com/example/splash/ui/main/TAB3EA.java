package com.example.splash.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.splash.R;
import com.example.splash.tourguidemoddel;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;




public class TAB3EA extends Fragment {
    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter2;
    private RecycleronClickListener2 listener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab3ea,container,false);
        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)v.findViewById(R.id.tourguide_list);
        setOnClickListener();


        Query query=db.collection("egypt_tour_guides");


        FirestoreRecyclerOptions<tourguidemoddel> options = new FirestoreRecyclerOptions.Builder<tourguidemoddel>().setQuery(query,tourguidemoddel.class).build();
        adapter2= new FirestoreRecyclerAdapter<tourguidemoddel, tourguideholder>(options) {

            @NonNull
            @Override
            public tourguideholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.glistrow,parent,false);

                return new tourguideholder(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull tourguideholder holder, int position, @NonNull tourguidemoddel model) {
                holder.list_name.setText(model.getName());
                holder.list_rate.setText(model.getRate());
                holder.list_pprice.setText(model.getPrice());
                holder.list_meeting.setText(model.getMeeting_point());
                holder.list_number.setText(model.getNumber());
                Picasso.get().load(Uri.parse(holder.imagepath=model.getImage())).into(holder.list_image);



            }
        };



        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getActivity()));
        mfirestorelist.setAdapter(adapter2);


        return v;

    }

    private void setOnClickListener() {

        listener= new RecycleronClickListener2() {
            @Override
            public void onClickkk(View v, int Position) {
                Toast.makeText(getActivity(), "calling tour guide", Toast.LENGTH_SHORT).show();
                Intent newInt = new Intent(Intent.ACTION_DIAL);
                startActivity(newInt);

            }
        };
    }


    private class tourguideholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView list_name;
        private TextView list_rate;
        private TextView list_pprice;
        private TextView list_meeting;
        public TextView list_number;
        private ImageView list_image;
        public   String imagepath;




        public tourguideholder(@NonNull View itemView) {
            super(itemView);

            list_name= itemView.findViewById(R.id.tgname);
            list_rate= itemView.findViewById(R.id.tgrate);
            list_pprice= itemView.findViewById(R.id.tgprice);
            list_meeting= itemView.findViewById(R.id.tgmeetpoint);
            list_number= itemView.findViewById(R.id.tgphone);
            list_image=itemView.findViewById(R.id.tgimage);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkk(itemView,getAdapterPosition());
        }
    }


    public  interface RecycleronClickListener2{
        void onClickkk(View v,int Position);


    }

    @Override
    public void onStart() {
        super.onStart();
        adapter2.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter2.stopListening();
    }


}
