package com.example.splash.ui.main;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.splash.R;
import com.example.splash.egyptrestaurantsmodel;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Tab2Ed extends Fragment {


    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter2;
    private RecycleronClickListener6 listener;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View v=inflater.inflate(R.layout.tab2ed,container,false);

        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)v.findViewById(R.id.egyptrestaurantsd_list);
        setOnClickListener();


        Query query=db.collection("egypt_restaurants");

        FirestoreRecyclerOptions<egyptrestaurantsmodel> options = new FirestoreRecyclerOptions.Builder<egyptrestaurantsmodel>().setQuery(query,egyptrestaurantsmodel.class).build();


        adapter2= new FirestoreRecyclerAdapter<egyptrestaurantsmodel, egyptrestaurantholderd>(options) {

            @NonNull
            @Override
            public egyptrestaurantholderd onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.egyptrestaurantsrow,parent,false);

                return new egyptrestaurantholderd(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull egyptrestaurantholderd holder, int position, @NonNull egyptrestaurantsmodel model) {
                holder.rname.setText(model.getRname());
                holder.rrate.setText(model.getRrate());
                holder.rworkinghrs.setText(model.getRworkinghrs());
                holder.raddress.setText(model.getRaddress());

                Picasso.get().load(Uri.parse(holder.rimage1=model.getRimage1())).into(holder.rimageview1);
                Picasso.get().load(Uri.parse(holder.rimage2=model.getRimage2())).into(holder.rimageview2);
                Picasso.get().load(Uri.parse(holder.rimage3=model.getRimage3())).into(holder.rimageview3);
                Picasso.get().load(Uri.parse(holder.rimage4=model.getRimage4())).into(holder.rimageview4);




            }
        };


        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getActivity()));
        mfirestorelist.setAdapter(adapter2);




        return v;
        }

    private void setOnClickListener() {

        listener= new RecycleronClickListener6() {
            @Override
            public void onClickkk(View v, int Position) {
                Toast.makeText(getActivity(), "table reserved", Toast.LENGTH_SHORT).show();

            }
        };
    }



    private class egyptrestaurantholderd extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView rname;
        private TextView rrate;
        private TextView rworkinghrs;
        private TextView raddress;
        private ImageView rimageview1;
        private ImageView rimageview2;
        private ImageView rimageview3;
        private ImageView rimageview4;
        public   String rimage1;
        public   String rimage2;
        public   String rimage3;
        public   String rimage4;




        public egyptrestaurantholderd(@NonNull View itemView) {
            super(itemView);

            rname= itemView.findViewById(R.id.rname);
            rrate= itemView.findViewById(R.id.raddress);
            rworkinghrs= itemView.findViewById(R.id.rrate);
            raddress= itemView.findViewById(R.id.rworkinghrs);

            rimageview1=itemView.findViewById(R.id.rimage1);
            rimageview2=itemView.findViewById(R.id.rimage2);
            rimageview3=itemView.findViewById(R.id.rimage3);
            rimageview4=itemView.findViewById(R.id.rimage4);
            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkk(itemView,getAdapterPosition());
        }
    }
    public  interface RecycleronClickListener6{
        void onClickkk(View v,int Position);


    }

    @Override
    public void onStart() {
        super.onStart();
        adapter2.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter2.stopListening();
    }



}
