package com.example.splash.ui.main.ui.main;

public class francehotelsmodel {
    public String hfname;
    public String hfaddress;
    public String hfrate;
    public String hfprice;
    public String hfimage1;
    public String hfimage2;
    public String hfimage3;
    public String hfimage4;

    public francehotelsmodel() {
    }


    public francehotelsmodel(String hfname, String hfaddress, String hfrate, String hfprice, String hfimage1, String hfimage2, String hfimage3, String hfimage4) {
        this.hfname = hfname;
        this.hfaddress = hfaddress;
        this.hfrate = hfrate;
        this.hfprice = hfprice;
        this.hfimage1 = hfimage1;
        this.hfimage2 = hfimage2;
        this.hfimage3 = hfimage3;
        this.hfimage4 = hfimage4;
    }

    public String getHfname() {
        return hfname;
    }

    public void setHfname(String hfname) {
        this.hfname = hfname;
    }

    public String getHfaddress() {
        return hfaddress;
    }

    public void setHfaddress(String hfaddress) {
        this.hfaddress = hfaddress;
    }

    public String getHfrate() {
        return hfrate;
    }

    public void setHfrate(String hfrate) {
        this.hfrate = hfrate;
    }

    public String getHfprice() {
        return hfprice;
    }

    public void setHfprice(String hfprice) {
        this.hfprice = hfprice;
    }

    public String getHfimage1() {
        return hfimage1;
    }

    public void setHfimage1(String hfimage1) {
        this.hfimage1 = hfimage1;
    }

    public String getHfimage2() {
        return hfimage2;
    }

    public void setHfimage2(String hfimage2) {
        this.hfimage2 = hfimage2;
    }

    public String getHfimage3() {
        return hfimage3;
    }

    public void setHfimage3(String hfimage3) {
        this.hfimage3 = hfimage3;
    }

    public String getHfimage4() {
        return hfimage4;
    }

    public void setHfimage4(String hfimage4) {
        this.hfimage4 = hfimage4;
    }
}
