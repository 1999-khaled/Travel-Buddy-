package com.example.splash.ui.main.ui.main;

import android.content.Context;

import com.example.splash.R;
import com.example.splash.ui.main.TAB1EA;
import com.example.splash.ui.main.TAB2EA;
import com.example.splash.ui.main.TAB3EA;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class SectionPagerAdapterAFrance extends FragmentPagerAdapter {

    @StringRes
    private static final int[] TAB_TITLES = new int[]{R.string.tab_text_1, R.string.tab_text_2};
    private final Context mContext;

    public SectionPagerAdapterAFrance(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new TAB1FA();
            case 1:
                return new TAB2FA();
            case 2:
                return new TAB3FA();

            default:
                return null;
        }
    }
    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position){
            case 0:
                return "Places";
            case 1:
                return "Flights";
            case 2:
                return "Guide";

            default:
                return null;


        }
    }

    @Override
    public int getCount() {
        return 3;
    }
}
