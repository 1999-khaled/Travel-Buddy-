package com.example.splash.ui.main.ui.main;

public class franceflightsmodel {

    public String fairline;
    public String fdate;
    public String ffighttime;
    public String ffrom;
    public String fprice;

    public franceflightsmodel() {
    }

    public franceflightsmodel(String fairline, String fdate, String ffighttime, String ffrom, String fprice) {
        this.fairline = fairline;
        this.fdate = fdate;
        this.ffighttime = ffighttime;
        this.ffrom = ffrom;
        this.fprice = fprice;
    }


    public String getFairline() {
        return fairline;
    }

    public void setFairline(String fairline) {
        this.fairline = fairline;
    }

    public String getFdate() {
        return fdate;
    }

    public void setFdate(String fdate) {
        this.fdate = fdate;
    }

    public String getFfighttime() {
        return ffighttime;
    }

    public void setFfighttime(String ffighttime) {
        this.ffighttime = ffighttime;
    }

    public String getFfrom() {
        return ffrom;
    }

    public void setFfrom(String ffrom) {
        this.ffrom = ffrom;
    }

    public String getFprice() {
        return fprice;
    }

    public void setFprice(String fprice) {
        this.fprice = fprice;
    }
}
