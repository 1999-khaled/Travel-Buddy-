package com.example.splash.ui.main.ui.main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.splash.R;
import com.example.splash.egypthotels;
import com.example.splash.egypthotelsmodel;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

public class francehotels extends AppCompatActivity {
    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter3;
    private egypthotels.RecycleronClickListener3 listener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_francehotels);

        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)findViewById(R.id.francehotels_list);
        setOnClickListener();

        Query query=db.collection("france_hotels");

        FirestoreRecyclerOptions<francehotelsmodel> options = new FirestoreRecyclerOptions.Builder<francehotelsmodel>().setQuery(query,francehotelsmodel.class).build();


        adapter3 = new FirestoreRecyclerAdapter<francehotelsmodel, francehotelholder>(options) {

            @NonNull
            @Override
            public francehotelholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.francehotelsrow,parent,false);

                return new francehotelholder(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull francehotelholder holder, int position, @NonNull francehotelsmodel model) {
                holder.hfname.setText(model.getHfname());
                holder.hfrate.setText(model.getHfrate());
                holder.hfprice.setText(model.getHfprice());
                holder.hfaddress.setText(model.getHfaddress());

                Picasso.get().load(Uri.parse(holder.hfimage1=model.getHfimage1())).into(holder.hfimageview1);
                Picasso.get().load(Uri.parse(holder.hfimage2=model.getHfimage2())).into(holder.hfimageview2);
                Picasso.get().load(Uri.parse(holder.hfimage3=model.getHfimage3())).into(holder.hfimageview3);
                Picasso.get().load(Uri.parse(holder.hfimage4=model.getHfimage4())).into(holder.hfimageview4);



            }
        };

        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mfirestorelist.setAdapter(adapter3);


    }


    private void setOnClickListener() {

        listener= new  egypthotels.RecycleronClickListener3() {
            @Override
            public void onClickkkk(View v, int Position) {
                Toast.makeText(getApplicationContext(), "opening site to book", Toast.LENGTH_SHORT).show();
                String url = "https://www.booking.com/hotel/eg/the-location.html?aid=397645;label=bin859jc-1DCAEoggI46AdIM1gDaEOIAQGYATG4ARfIAQzYAQPoAQH4AQKIAgGoAgO4AqbvkoAGwAIB0gIkZTBlN2U2NDktZjQ1NS00NjYwLTlkY2QtOTg5NDg3NDNiY2Zk2AIE4AIB;sid=bf1e3104588b94674c683f027c06f6e8;checkin=2021-01-17;checkout=2021-01-18&";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }


        };


    }

    private class francehotelholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView hfname;
        private TextView hfrate;
        private TextView hfprice;
        private TextView hfaddress;
        private ImageView hfimageview1;
        private ImageView hfimageview2;
        private ImageView hfimageview3;
        private ImageView hfimageview4;
        public   String hfimage1;
        public   String hfimage2;
        public   String hfimage3;
        public   String hfimage4;




        public francehotelholder(@NonNull View itemView) {
            super(itemView);

            hfname= itemView.findViewById(R.id.hfname);
            hfaddress= itemView.findViewById(R.id.hfaddress);
            hfrate= itemView.findViewById(R.id.hfrate);
            hfprice= itemView.findViewById(R.id.hfprice);

            hfimageview1=itemView.findViewById(R.id.fimage1);
            hfimageview2=itemView.findViewById(R.id.fimage2);
            hfimageview3=itemView.findViewById(R.id.fimage3);
            hfimageview4=itemView.findViewById(R.id.fimage4);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkkk(itemView,getAdapterPosition());
        }
    }


    public  interface RecycleronClickListener3{
        void onClickkkk(View v,int Position);


    }


    @Override
    public void onStart() {
        super.onStart();
        adapter3.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter3.stopListening();
    }
}