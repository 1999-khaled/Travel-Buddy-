package com.example.splash.ui.main.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.splash.R;
import com.example.splash.tourguidemoddel;
import com.example.splash.ui.main.TAB3EA;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TAB3FA extends Fragment {

    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter2;
    private TAB3EA.RecycleronClickListener2 listener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab3fa,container,false);
        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)v.findViewById(R.id.francetourguide_list);
        setOnClickListener();


        Query query=db.collection("france_tourguides");


        FirestoreRecyclerOptions<francetourguidemodel> options = new FirestoreRecyclerOptions.Builder<francetourguidemodel>().setQuery(query,francetourguidemodel.class).build();
        adapter2= new FirestoreRecyclerAdapter<francetourguidemodel, francetourguideholder>(options) {

            @NonNull
            @Override
            public francetourguideholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.fglist,parent,false);

                return new francetourguideholder(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull francetourguideholder holder, int position, @NonNull francetourguidemodel model) {
                holder.flist_name.setText(model.getFgname());
                holder.flist_rate.setText(model.getFgrate());
                holder.flist_pprice.setText(model.getFgprice());
                holder.flist_meeting.setText(model.getFgmeetingpoint());
                holder.flist_number.setText(model.getFgnumber());
                Picasso.get().load(Uri.parse(holder.fimagepath=model.getFimage())).into(holder.flist_image);



            }
        };



        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getActivity()));
        mfirestorelist.setAdapter(adapter2);


        return v;

    }

    private void setOnClickListener() {

        listener= new TAB3EA.RecycleronClickListener2() {
            @Override
            public void onClickkk(View v, int Position) {
                Toast.makeText(getActivity(), "calling tour guide", Toast.LENGTH_SHORT).show();
                Intent newInt = new Intent(Intent.ACTION_DIAL);
                startActivity(newInt);

            }
        };
    }


    private class francetourguideholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView flist_name;
        private TextView flist_rate;
        private TextView flist_pprice;
        private TextView flist_meeting;
        public TextView flist_number;
        private ImageView flist_image;
        public   String fimagepath;




        public francetourguideholder(@NonNull View itemView) {
            super(itemView);

            flist_name= itemView.findViewById(R.id.ftgname);
            flist_rate= itemView.findViewById(R.id.ftgrate);
            flist_pprice= itemView.findViewById(R.id.ftgprice);
            flist_meeting= itemView.findViewById(R.id.ftgmeetpoint);
            flist_number= itemView.findViewById(R.id.ftgphone);
            flist_image=itemView.findViewById(R.id.ftgimage);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkk(itemView,getAdapterPosition());
        }
    }


    public  interface RecycleronClickListener2{
        void onClickkk(View v,int Position);


    }

    @Override
    public void onStart() {
        super.onStart();
        adapter2.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter2.stopListening();
    }

}
