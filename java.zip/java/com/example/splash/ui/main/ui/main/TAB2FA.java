package com.example.splash.ui.main.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.example.splash.R;
import com.example.splash.ui.main.TAB2EA;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TAB2FA extends Fragment {
    private FirebaseFirestore db;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter;
    private TAB2EA.RecycleronClickListener listener;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab2fa,container,false);
        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)v.findViewById(R.id.franceflights_list);
        setOnClickListener();
        //query
        Query query=db.collection("france_flights");
        //recycleroptions
        FirestoreRecyclerOptions<franceflightsmodel> options = new FirestoreRecyclerOptions.Builder<franceflightsmodel>().setQuery(query,franceflightsmodel.class).build();
        adapter= new FirestoreRecyclerAdapter<franceflightsmodel, franceflightholder>(options) {
            @NonNull
            @Override
            public franceflightholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.franceflightrow,parent,false);

                return new franceflightholder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull franceflightholder holder, int position, @NonNull franceflightsmodel model) {
                holder.flist_from.setText(model.getFfrom());
                holder.flist_date.setText(model.getFdate());
                holder.flist_price.setText(model.getFprice());
                holder.flist_time.setText(model.getFfighttime());
                holder.flist_airline.setText(model.getFairline());
            }
        };
        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getActivity()));
        mfirestorelist.setAdapter(adapter);


        return v;


    }

    private void setOnClickListener() {

        listener= new TAB2EA.RecycleronClickListener() {
            @Override
            public void onClickk(View v, int Position) {
                Toast.makeText(getActivity(), "Opening site to book flight", Toast.LENGTH_SHORT).show();
                String url = "https://www.emirates.com/ae/english/";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        };
    }

    private class franceflightholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView flist_from;
        private TextView flist_date;
        private TextView flist_price;
        private TextView flist_time;
        private TextView flist_airline;



        public franceflightholder(@NonNull View itemView) {
            super(itemView);

            flist_from= itemView.findViewById(R.id.ffromto);
            flist_date= itemView.findViewById(R.id.fdate);
            flist_price= itemView.findViewById(R.id.fprice);
            flist_time= itemView.findViewById(R.id.ftimeofflight);
            flist_airline= itemView.findViewById(R.id.fairlines);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickk(itemView,getAdapterPosition());
        }
    }

    public  interface RecycleronClickListener{
        void onClickk(View v,int Position);


    }


    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }



}
