package com.example.splash.ui.main.ui.main;

public class francerestaurantmodel {

    public String frname;
    public String fraddress;
    public String frrate;
    public String frworkinghrs;
    public String frimage1;
    public String frimage2;
    public String frimage3;
    public String frimage4;


    public francerestaurantmodel() {
    }


    public francerestaurantmodel(String frname, String fraddress, String frrate, String frworkinghrs, String frimage1, String frimage2, String frimage3, String frimage4) {
        this.frname = frname;
        this.fraddress = fraddress;
        this.frrate = frrate;
        this.frworkinghrs = frworkinghrs;
        this.frimage1 = frimage1;
        this.frimage2 = frimage2;
        this.frimage3 = frimage3;
        this.frimage4 = frimage4;
    }


    public String getFrname() {
        return frname;
    }

    public void setFrname(String frname) {
        this.frname = frname;
    }

    public String getFraddress() {
        return fraddress;
    }

    public void setFraddress(String fraddress) {
        this.fraddress = fraddress;
    }

    public String getFrrate() {
        return frrate;
    }

    public void setFrrate(String frrate) {
        this.frrate = frrate;
    }

    public String getFrworkinghrs() {
        return frworkinghrs;
    }

    public void setFrworkinghrs(String frworkinghrs) {
        this.frworkinghrs = frworkinghrs;
    }

    public String getFrimage1() {
        return frimage1;
    }

    public void setFrimage1(String frimage1) {
        this.frimage1 = frimage1;
    }

    public String getFrimage2() {
        return frimage2;
    }

    public void setFrimage2(String frimage2) {
        this.frimage2 = frimage2;
    }

    public String getFrimage3() {
        return frimage3;
    }

    public void setFrimage3(String frimage3) {
        this.frimage3 = frimage3;
    }

    public String getFrimage4() {
        return frimage4;
    }

    public void setFrimage4(String frimage4) {
        this.frimage4 = frimage4;
    }
}
