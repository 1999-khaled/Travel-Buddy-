package com.example.splash.ui.main.ui.main;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.splash.R;
import com.example.splash.egyptplacesvr;

public class franceplacevr extends AppCompatActivity {
    Button btn,clr;
    WebView eiffeltower;
    WebView secondlandmark;
    EditText txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_franceplacevr);
        btn=(Button)findViewById(R.id.flandmarlsrch);
        clr=(Button)findViewById(R.id.fclear);
        eiffeltower=(WebView)findViewById(R.id.eiffeltower);
        secondlandmark=(WebView)findViewById(R.id.secondlandmark);
        txt=(EditText)findViewById(R.id.fvrsearch);
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eiffeltower.setVisibility(View.INVISIBLE);
                secondlandmark.setVisibility(View.INVISIBLE);
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=txt.getText().toString().trim();
                if(s.equals("eiffeltower")){
                    eiffeltower.setWebViewClient(new WebViewClient());
                    eiffeltower.getSettings().setJavaScriptEnabled(true);
                    eiffeltower.loadUrl("http://www.airpano.com/vtour_mobile/eiffel-tower-paris-france/");
                    eiffeltower.setVisibility(View.VISIBLE);

                }
                else if(s.equals("nice")){

                    secondlandmark.setWebViewClient(new WebViewClient());
                    secondlandmark.getSettings().setJavaScriptEnabled(true);
                    secondlandmark.loadUrl("https://www.airpano.com/vtour_mobile/nice-france/");
                    secondlandmark.setVisibility(View.VISIBLE);

                }
                else {
                    Toast.makeText(franceplacevr.this, "Can't find the item you're searching for", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}