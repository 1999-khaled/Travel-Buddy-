package com.example.splash.ui.main.ui.main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.splash.R;
import com.example.splash.egyptrestaurants;
import com.example.splash.egyptrestaurantsmodel;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

public class francerestaurants extends AppCompatActivity {


    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter4;
    private egyptrestaurants.RecycleronClickListener4 listener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_francerestaurants);


        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)findViewById(R.id.francerestaurants_list);
        setOnClickListener();

        Query query=db.collection("france_restaurants");

        FirestoreRecyclerOptions<francerestaurantmodel> options = new FirestoreRecyclerOptions.Builder<francerestaurantmodel>().setQuery(query,francerestaurantmodel.class).build();

        adapter4 = new FirestoreRecyclerAdapter<francerestaurantmodel, francerestaurantholder>(options) {

            @NonNull
            @Override
            public francerestaurantholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.francerestaurantrow,parent,false);

                return new francerestaurantholder(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull francerestaurantholder holder, int position, @NonNull francerestaurantmodel model) {
                holder.frname.setText(model.getFrname());
                holder.frrate.setText(model.getFrrate());
                holder.frworkinghrs.setText(model.getFrworkinghrs());
                holder.fraddress.setText(model.getFraddress());

                Picasso.get().load(Uri.parse(holder.frimage1=model.getFrimage1())).into(holder.frimageview1);
                Picasso.get().load(Uri.parse(holder.frimage2=model.getFrimage2())).into(holder.frimageview2);
                Picasso.get().load(Uri.parse(holder.frimage3=model.getFrimage3())).into(holder.frimageview3);
                Picasso.get().load(Uri.parse(holder.frimage4=model.getFrimage4())).into(holder.frimageview4);



            }
        };



        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mfirestorelist.setAdapter(adapter4);





    }

    private void setOnClickListener() {

        listener= new egyptrestaurants.RecycleronClickListener4() {
            @Override
            public void onClickkkkk(View v, int Position) {
                Toast.makeText(getApplicationContext(), "table reserved", Toast.LENGTH_SHORT).show();
            }


        };


    }

    private class francerestaurantholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView frname;
        private TextView frrate;
        private TextView frworkinghrs;
        private TextView fraddress;
        private ImageView frimageview1;
        private ImageView frimageview2;
        private ImageView frimageview3;
        private ImageView frimageview4;
        public   String frimage1;
        public   String frimage2;
        public   String frimage3;
        public   String frimage4;




        public francerestaurantholder(@NonNull View itemView) {
            super(itemView);

            frname= itemView.findViewById(R.id.rname);
            frrate= itemView.findViewById(R.id.raddress);
            frworkinghrs= itemView.findViewById(R.id.rrate);
            fraddress= itemView.findViewById(R.id.rworkinghrs);

            frimageview1=itemView.findViewById(R.id.rimage1);
            frimageview2=itemView.findViewById(R.id.rimage2);
            frimageview3=itemView.findViewById(R.id.rimage3);
            frimageview4=itemView.findViewById(R.id.rimage4);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkkkk(itemView,getAdapterPosition());
        }
    }
    public  interface RecycleronClickListener4{
        void onClickkkkk(View v,int Position);


    }


    @Override
    public void onStart() {
        super.onStart();
        adapter4.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter4.stopListening();
    }

}