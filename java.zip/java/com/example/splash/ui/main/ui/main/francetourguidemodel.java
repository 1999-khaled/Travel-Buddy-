package com.example.splash.ui.main.ui.main;

public class francetourguidemodel {
    public String fgname;
    public String fgmeetingpoint;
    public String fgprice;
    public String fgrate;
    public String fgnumber;
    public String fimage;


    public francetourguidemodel() {
    }

    public francetourguidemodel(String fgname, String fgmeetingpoint, String fgprice, String fgrate, String fgnumber, String fimage) {
        this.fgname = fgname;
        this.fgmeetingpoint = fgmeetingpoint;
        this.fgprice = fgprice;
        this.fgrate = fgrate;
        this.fgnumber = fgnumber;
        this.fimage = fimage;
    }


    public String getFgname() {
        return fgname;
    }

    public void setFgname(String fgname) {
        this.fgname = fgname;
    }

    public String getFgmeetingpoint() {
        return fgmeetingpoint;
    }

    public void setFgmeetingpoint(String fgmeetingpoint) {
        this.fgmeetingpoint = fgmeetingpoint;
    }

    public String getFgprice() {
        return fgprice;
    }

    public void setFgprice(String fgprice) {
        this.fgprice = fgprice;
    }

    public String getFgrate() {
        return fgrate;
    }

    public void setFgrate(String fgrate) {
        this.fgrate = fgrate;
    }

    public String getFgnumber() {
        return fgnumber;
    }

    public void setFgnumber(String fgnumber) {
        this.fgnumber = fgnumber;
    }

    public String getFimage() {
        return fimage;
    }

    public void setFimage(String fimage) {
        this.fimage = fimage;
    }
}
