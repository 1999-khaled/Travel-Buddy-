package com.example.splash.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.example.splash.R;
import com.example.splash.flightegyptmodel;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TAB2EA extends Fragment {
    private FirebaseFirestore db;
   private RecyclerView mfirestorelist;
   private  FirestoreRecyclerAdapter adapter;
   private RecycleronClickListener listener;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab2ea,container,false);
        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)v.findViewById(R.id.firestore_list);
        setOnClickListener();
        //query
        Query query=db.collection("flightsfromegypt");
        //recycleroptions
        FirestoreRecyclerOptions <flightegyptmodel> options = new FirestoreRecyclerOptions.Builder<flightegyptmodel>().setQuery(query,flightegyptmodel.class).build();
         adapter= new FirestoreRecyclerAdapter<flightegyptmodel, flightsviewholder>(options) {
            @NonNull
            @Override
            public flightsviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.flight_egyptlist,parent,false);

                return new flightsviewholder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull flightsviewholder holder, int position, @NonNull flightegyptmodel model) {
                    holder.list_from.setText(model.getFrom());
                    holder.list_date.setText(model.getDate());
                    holder.list_price.setText(model.getPrice());
                    holder.list_time.setText(model.getFighttime());
                    holder.list_airline.setText(model.getAirline());
            }
        };
         mfirestorelist.setHasFixedSize(true);
         mfirestorelist.setLayoutManager(new LinearLayoutManager(getActivity()));
         mfirestorelist.setAdapter(adapter);


        return v;


    }

    private void setOnClickListener() {

        listener= new RecycleronClickListener() {
            @Override
            public void onClickk(View v, int Position) {
                Toast.makeText(getActivity(), "Opening site to book flight", Toast.LENGTH_SHORT).show();
                String url = "https://www.emirates.com/ae/english/";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        };
    }

    private class flightsviewholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView list_from;
        private TextView list_date;
        private TextView list_price;
        private TextView list_time;
        private TextView list_airline;



        public flightsviewholder(@NonNull View itemView) {
            super(itemView);

            list_from= itemView.findViewById(R.id.fromto);
            list_date= itemView.findViewById(R.id.date);
            list_price= itemView.findViewById(R.id.price);
            list_time= itemView.findViewById(R.id.timeofflight);
            list_airline= itemView.findViewById(R.id.airlines);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickk(itemView,getAdapterPosition());
        }
    }

    public  interface RecycleronClickListener{
        void onClickk(View v,int Position);


    }


    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }





}
