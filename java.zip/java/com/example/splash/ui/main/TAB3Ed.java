package com.example.splash.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.splash.R;
import com.example.splash.egyptactivitymodel;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TAB3Ed extends Fragment {
    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter3;
    private RecycleronClickListener3 listener;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab3ed,container,false);
        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)v.findViewById(R.id.activity_list);
        setOnClickListener();


        Query query=db.collection("degypt_activities");

        FirestoreRecyclerOptions<egyptactivitymodel> options = new FirestoreRecyclerOptions.Builder<egyptactivitymodel>().setQuery(query,egyptactivitymodel.class).build();
        adapter3 = new FirestoreRecyclerAdapter<egyptactivitymodel,egyptactivityholder>(options) {

            @NonNull
            @Override
            public egyptactivityholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.activityyy_row,parent,false);

                return new egyptactivityholder(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull egyptactivityholder holder, int position, @NonNull egyptactivitymodel model) {
                holder.city.setText(model.getCity());
                holder.aname.setText(model.getAname());
                holder.aprice.setText(model.getAprice());

                Picasso.get().load(Uri.parse(holder.aimage1=model.getAimage())).into(holder.aimageview1);




            }
        };


        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getActivity()));
        mfirestorelist.setAdapter(adapter3);

        return v;
    }

    private void setOnClickListener() {

        listener= new  RecycleronClickListener3() {
            @Override
            public void onClickkkk(View v, int Position) {
                Toast.makeText(getActivity(), "calling", Toast.LENGTH_SHORT).show();

                Intent newInt = new Intent(Intent.ACTION_DIAL);
                startActivity(newInt);

            }


        };


    }

    private class egyptactivityholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView city;
        private TextView aname;
        private TextView aprice;
        private ImageView aimageview1;
        public   String aimage1;




        public egyptactivityholder(@NonNull View itemView) {
            super(itemView);

            city= itemView.findViewById(R.id.acity);
            aname= itemView.findViewById(R.id.daname);
            aprice= itemView.findViewById(R.id.aprice);
            aimageview1=itemView.findViewById(R.id.aimage1);


            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkkk(itemView,getAdapterPosition());
        }
    }
    public  interface RecycleronClickListener3{
        void onClickkkk(View v,int Position);


    }


    @Override
    public void onStart() {
        super.onStart();
        adapter3.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter3.stopListening();
    }
}
