package com.example.splash.ui.main;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.splash.R;
import com.example.splash.egyptdtripsmodel;
import com.example.splash.egypthotels;
import com.example.splash.egypthotelsmodel;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TAB1Ed extends Fragment {

    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter3;
    private RecycleronClickListener3 listener;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab1ed,container,false);

        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)v.findViewById(R.id.egypttripslist);
        setOnClickListener();


        Query query=db.collection("degypt_trips");

        FirestoreRecyclerOptions<egyptdtripsmodel> options = new FirestoreRecyclerOptions.Builder<egyptdtripsmodel>().setQuery(query,egyptdtripsmodel.class).build();

        adapter3 = new FirestoreRecyclerAdapter<egyptdtripsmodel, egyptdtripsholder>(options) {

            @NonNull
            @Override
            public egyptdtripsholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.egyptdtripsrow,parent,false);

                return new egyptdtripsholder(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull egyptdtripsholder holder, int position, @NonNull egyptdtripsmodel model) {
                holder.contact.setText(model.getContact());
                holder.no_of_days.setText(model.getNo_of_days());
                holder.place.setText(model.getPlace());
                holder.transportation.setText(model.getTransportation());
                holder.price.setText(model.getPrice());

                Picasso.get().load(Uri.parse(holder.dtimage1=model.getDtimage1())).into(holder.dtimageview1);
                Picasso.get().load(Uri.parse(holder.dtimage2=model.getDtimage2())).into(holder.dtimageview2);
                Picasso.get().load(Uri.parse(holder.dtimage3=model.getDtimage3())).into(holder.dtimageview3);
                Picasso.get().load(Uri.parse(holder.dtimage4=model.getDtimage4())).into(holder.dtimageview4);



            }
        };
        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getActivity()));
        mfirestorelist.setAdapter(adapter3);


        return  v;
    }


    private void setOnClickListener() {

        listener= new RecycleronClickListener3() {
            @Override
            public void onClickkkk(View v, int Position) {
                Toast.makeText(getActivity(), "calling", Toast.LENGTH_SHORT).show();

                Intent newInt = new Intent(Intent.ACTION_DIAL);
                startActivity(newInt);

            }


        };


    }

    private class egyptdtripsholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView contact;
        private TextView no_of_days;
        private TextView place;
        private TextView price;
        private TextView transportation;
        private ImageView dtimageview1;
        private ImageView dtimageview2;
        private ImageView dtimageview3;
        private ImageView dtimageview4;
        public   String dtimage1;
        public   String dtimage2;
        public   String dtimage3;
        public   String dtimage4;




        public egyptdtripsholder(@NonNull View itemView) {
            super(itemView);

            contact= itemView.findViewById(R.id.dtcontact);
            no_of_days= itemView.findViewById(R.id.dtnoofdays);
            place= itemView.findViewById(R.id.dtplace);
            transportation= itemView.findViewById(R.id.dtrans);
            price= itemView.findViewById(R.id.dtprice);

            dtimageview1=itemView.findViewById(R.id.dtimage1);
            dtimageview2=itemView.findViewById(R.id.dtimage2);
            dtimageview3=itemView.findViewById(R.id.dtimage3);
            dtimageview4=itemView.findViewById(R.id.dtimage4);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkkk(itemView,getAdapterPosition());
        }
    }
    public  interface RecycleronClickListener3{
        void onClickkkk(View v,int Position);


    }


    @Override
    public void onStart() {
        super.onStart();
        adapter3.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter3.stopListening();
    }
}
