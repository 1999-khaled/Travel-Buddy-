package com.example.splash;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.VideoView;


public class MainActivity extends AppCompatActivity {
    private VideoView v;
    Animation goup;
    TextView W;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        goup= AnimationUtils.loadAnimation(this,R.anim.goup);
        W=(TextView)findViewById(R.id.textView);
        v=(VideoView)findViewById(R.id.videoView);
        v.setVideoPath("android.resource://"+getPackageName()+"/"+R.raw.anim);
        v.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                if(isFinishing())
                    return;
                    Intent i =new Intent(getApplicationContext(), login.class);
                   Pair[] pairs=new Pair[2];
                   pairs[0]=new Pair<View,String>(v,"logo");
                   pairs[1]=new Pair<View,String>(W,"logo_text");
                ActivityOptions options = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    options = ActivityOptions.makeSceneTransitionAnimation(MainActivity.this,pairs);
                }
                startActivity(i,options.toBundle());

            }
        });
        v.start();
        W.setAnimation(goup);
    }
}