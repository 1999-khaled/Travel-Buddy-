package com.example.splash;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class signup extends AppCompatActivity {
    private static final Pattern pass_pattern=
            Pattern.compile("^"+
                    "(?=.*[@#$%^&+_=])"+
                    "(?=\\S+$)"+
                    ".{4,}"+
                    "$");
    public static final String TAG = "TAG";

    EditText regPass,regconfirmpass,regUsername,regEmail,regPhoneno;
    Button regbtn,regtologinbtn;
    ConstraintLayout mlayout;
    AnimationDrawable mdrawable;
    ImageView image;
    TextView txt1,txt2;
    ProgressBar bar;
    FirebaseAuth fauth;
    FirebaseFirestore fbfs;
    String userid;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_signup);
        mlayout=(ConstraintLayout)findViewById(R.id.layout);
        mdrawable=(AnimationDrawable)mlayout.getBackground();
        mdrawable.setEnterFadeDuration(3000);
        mdrawable.setExitFadeDuration(3000);
        mdrawable.start();

        fauth=FirebaseAuth.getInstance();
        fbfs=FirebaseFirestore.getInstance();


        bar=(ProgressBar)findViewById(R.id.progressBar);
        image=(ImageView)findViewById(R.id.imageView);
        txt1=(TextView)findViewById(R.id.textView2);
        txt2=(TextView)findViewById(R.id.textView3);
        regUsername=(EditText)findViewById(R.id.txt);
        regEmail=(EditText)findViewById(R.id.Email);
        regPhoneno=(EditText)findViewById(R.id.phone);
        regPass=(EditText)findViewById(R.id.pass);
        regconfirmpass=(EditText)findViewById(R.id.confirm_pass);
        regbtn=(Button) findViewById(R.id.button2);
        regtologinbtn=(Button) findViewById(R.id.back);

       /*if(fauth.getCurrentUser() !=null){
           Toast.makeText(signup.this, "Account already created", Toast.LENGTH_SHORT).show();
           Intent i=new Intent(getApplicationContext(),Firstpage.class);
           startActivity(i);
           finish();

       }*/


        regtologinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(getApplicationContext(), login.class);
                Pair[] pairs=new Pair[7];
                pairs[0]= new Pair<View,String>(image,"logo");
                pairs[1]= new Pair<View,String>(regUsername,"username_text");
                pairs[2]= new Pair<View,String>(regbtn,"login_button");
                pairs[3]= new Pair<View,String>(regPass,"pass_text");
                pairs[4]= new Pair<View,String>(regtologinbtn,"login_signup_trans");
                pairs[5]= new Pair<View,String>(txt1,"logo_text");
                pairs[6]= new Pair<View,String>(txt2,"smalltext");
                ActivityOptions options = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    options= ActivityOptions.makeSceneTransitionAnimation(signup.this,pairs);
                }
                startActivity(i,options.toBundle());

            }
        });



        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String usernameinput=regUsername.getText().toString().trim();
                final String emailinput=regEmail.getText().toString().trim();
                final String phoneinput=regPhoneno.getText().toString().trim();
                String passinput=regPass.getText().toString().trim();
                String confirminput=regconfirmpass.getText().toString().trim();



               if(emailinput.isEmpty()){
                   regEmail.setError("this field can't be empty");
                   return;
               }
                if(!Patterns.EMAIL_ADDRESS.matcher(emailinput).matches()){

                    regEmail.setError("incorrect email address");
                    return;
                }
                if(passinput.isEmpty()){
                    regPass.setError("this field can't be empty");
                    return;

                }
                if(confirminput.isEmpty()){
                    regconfirmpass.setError("this field can't be empty");
                    return;

                }
                if(!pass_pattern.matcher(passinput).matches()){
                    regPass.setError("password too weak");
                    return;
                }
                if(!confirminput.equals(passinput)){
                    regconfirmpass.setError("this isn't the same password from previous field");
                    return;

                }
                if(phoneinput.isEmpty()){

                    regPhoneno.setError("this field can't be empty");
                    return;
                }
                if(phoneinput.length()<=10){
                    regPhoneno.setError("incorrect phone number");
                    return;
                }
                if(usernameinput.isEmpty()){

                    regUsername.setError("this field can't be empty");
                    return;
                }
                if(usernameinput.length()>15||usernameinput.length()<5){

                    regUsername.setError("username can't exceed 15 characters");
                    return;

                }
                bar.setVisibility(View.VISIBLE);
                fauth.createUserWithEmailAndPassword(emailinput,passinput).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(signup.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                            userid= fauth.getCurrentUser().getUid();
                            DocumentReference documentReference= fbfs.collection("users").document(userid);
                            Map<String,Object> user=new HashMap<>();
                            user.put("Name",usernameinput);
                            user.put("E-mail",emailinput);
                            user.put("Phone#",phoneinput);
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG,"on Success: Welcome"+userid);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG,"on Success: "+e.toString());
                                }
                            });
                            Intent i=new Intent(getApplicationContext(),Home_page.class);
                            startActivity(i);
                        }else{
                            Toast.makeText(signup.this, "Error!"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            bar.setVisibility(View.INVISIBLE);

                        }
                    }
                });



            }
        });

    }







}