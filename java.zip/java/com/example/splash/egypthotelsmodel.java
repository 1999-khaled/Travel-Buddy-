package com.example.splash;

public class egypthotelsmodel {
    public String hname;
    public String haddress;
    public String hrate;
    public String hprice;
    public String himage1;
    public String himage2;
    public String himage3;
    public String himage4;

    public egypthotelsmodel(){}
    public egypthotelsmodel(String hname,String haddress,String hprice, String hrate,String himage1,String himage2,String himage3,String himage4){
        this.haddress=haddress;
        this.himage1=himage1;
        this.himage2=himage2;
        this.himage3=himage3;
        this.himage4=himage4;
        this.hname=hname;
        this.hrate=hrate;
        this.hprice=hprice;

    }

    public String getHname() {
        return hname;
    }

    public void setHname(String hname) {
        this.hname = hname;
    }

    public String getHaddress() {
        return haddress;
    }

    public void setHaddress(String haddress) {
        this.haddress = haddress;
    }

    public String getHrate() {
        return hrate;
    }

    public void setHrate(String hrate) {
        this.hrate = hrate;
    }

    public String getHprice() {
        return hprice;
    }

    public void setHprice(String hprice) {
        this.hprice = hprice;
    }

    public String getHimage1() {
        return himage1;
    }

    public void setHimage1(String himage1) {
        this.himage1 = himage1;
    }

    public String getHimage2() {
        return himage2;
    }

    public void setHimage2(String himage2) {
        this.himage2 = himage2;
    }

    public String getHimage3() {
        return himage3;
    }

    public void setHimage3(String himage3) {
        this.himage3 = himage3;
    }

    public String getHimage4() {
        return himage4;
    }

    public void setHimage4(String himage4) {
        this.himage4 = himage4;
    }
}
