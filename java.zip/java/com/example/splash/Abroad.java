package com.example.splash;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Abroad extends AppCompatActivity {
    CardView egypt,france;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abroad);
        egypt=(CardView)findViewById(R.id.egypt);
        france=(CardView)findViewById(R.id.france);


        egypt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),aegypta.class);
                startActivity(i);
            }
        });



        france.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),aFrancea.class);
                startActivity(i);
            }
        });
    }
}