package com.example.splash;

import android.os.Bundle;
import com.example.splash.ui.main.SectionPagerAdapterdegypt;
import com.google.android.material.tabs.TabLayout;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

public class dEgypt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_egypt);
        SectionPagerAdapterdegypt sectionsPagerAdapter = new SectionPagerAdapterdegypt(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager2);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs2);
        tabs.setupWithViewPager(viewPager);


        tabs.getTabAt(0).setIcon(R.drawable.ic_baseline_beach_access_24);
        tabs.getTabAt(1).setIcon(R.drawable.ic_baseline_fastfood_24);
        tabs.getTabAt(2).setIcon(R.drawable.ic_baseline_directions_bike_24);


    }
}