package com.example.splash;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {
ConstraintLayout mlayout;
AnimationDrawable mdrawable;
Button Callsignup,login_btn,fbtn;
ImageView image;
TextView txt1,txt2;
EditText pass,email;
ProgressBar bar;
FirebaseAuth fauth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main2);

        Callsignup=(Button)findViewById(R.id.signupp);
        image=(ImageView)findViewById(R.id.imageView);
        login_btn=(Button)findViewById(R.id.button2);
        pass=(EditText)findViewById(R.id.pass);
        txt1=(TextView)findViewById(R.id.textView2);
        txt2=(TextView)findViewById(R.id.textView3);
        bar=(ProgressBar)findViewById(R.id.progressBar);
        email=(EditText)findViewById(R.id.txt);
        fbtn=(Button)findViewById(R.id.forgot_btn);

        fauth=FirebaseAuth.getInstance();


        mlayout=(ConstraintLayout)findViewById(R.id.layout);
        mdrawable=(AnimationDrawable)mlayout.getBackground();
        mdrawable.setEnterFadeDuration(3000);
        mdrawable.setExitFadeDuration(3000);
        mdrawable.start();
        Callsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(getApplicationContext(), signup.class);
                Pair[] pairs=new Pair[7];
                pairs[0]= new Pair<View,String>(image,"logo");
                pairs[1]= new Pair<View,String>(email,"username_text");
                pairs[2]= new Pair<View,String>(login_btn,"login_button");
                pairs[3]= new Pair<View,String>(pass,"pass_text");
                pairs[4]= new Pair<View,String>(Callsignup,"login_signup_trans");
                pairs[5]= new Pair<View,String>(txt1,"logo_text");
                pairs[6]= new Pair<View,String>(txt2,"smalltext");
                ActivityOptions options = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                     options= ActivityOptions.makeSceneTransitionAnimation(login.this,pairs);
                    startActivity(i,options.toBundle());

                }
            }
        });

        fbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText resetmail= new EditText(v.getContext());
                AlertDialog.Builder passwordResetDialog=new AlertDialog.Builder(v.getContext());
                passwordResetDialog.setTitle("Reset password");
                passwordResetDialog.setMessage("Enter your email to reset the password");
                passwordResetDialog.setView(resetmail);
                passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String mail= resetmail.getText().toString();
                        fauth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(login.this, "Reset link sent to your E-mail successfully ", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(login.this, "Error!"+e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                passwordResetDialog.create().show();
            }
        });



        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailinput=email.getText().toString().trim();
                String passinput=pass.getText().toString().trim();
                if(emailinput.isEmpty()){
                    email.setError("this field can't be empty");
                    return;
                }
                if(passinput.isEmpty()){
                    pass.setError("this field can't be empty");
                    return;

                }
                bar.setVisibility(View.VISIBLE);
                fauth.signInWithEmailAndPassword(emailinput,passinput).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(login.this, "Login Complete", Toast.LENGTH_SHORT).show();
                        Intent i=new Intent(getApplicationContext(),Home_page.class);
                        startActivity(i);
                    } else{
                        Toast.makeText(login.this, "Error!"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        bar.setVisibility(View.INVISIBLE);
                    }
                    }
                });



            }
        });


         }


}