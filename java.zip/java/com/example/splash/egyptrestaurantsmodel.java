package com.example.splash;

public class egyptrestaurantsmodel {

    public String rname;
    public String raddress;
    public String rrate;
    public String rworkinghrs;
    public String rimage1;
    public String rimage2;
    public String rimage3;
    public String rimage4;


    public egyptrestaurantsmodel(){}
    public egyptrestaurantsmodel(String rname,String raddress,String rrate,String rworkinghrs,String rimage1, String rimage2, String rimage3,String rimage4){

        this.raddress=raddress;
        this.rimage1=rimage1;
        this.rimage2=rimage2;
        this.rimage3=rimage3;
        this.rimage4=rimage4;
        this.rname=rname;
        this.rrate=rrate;
        this.rworkinghrs=rworkinghrs;


    }


    public String getRname() {
        return rname;
    }

    public void setRname(String rname) {
        this.rname = rname;
    }

    public String getRaddress() {
        return raddress;
    }

    public void setRaddress(String raddress) {
        this.raddress = raddress;
    }

    public String getRrate() {
        return rrate;
    }

    public void setRrate(String rrate) {
        this.rrate = rrate;
    }

    public String getRworkinghrs() {
        return rworkinghrs;
    }

    public void setRworkinghrs(String rworkinghrs) {
        this.rworkinghrs = rworkinghrs;
    }

    public String getRimage1() {
        return rimage1;
    }

    public void setRimage1(String rimage1) {
        this.rimage1 = rimage1;
    }

    public String getRimage2() {
        return rimage2;
    }

    public void setRimage2(String rimage2) {
        this.rimage2 = rimage2;
    }

    public String getRimage3() {
        return rimage3;
    }

    public void setRimage3(String rimage3) {
        this.rimage3 = rimage3;
    }

    public String getRimage4() {
        return rimage4;
    }

    public void setRimage4(String rimage4) {
        this.rimage4 = rimage4;
    }
}
