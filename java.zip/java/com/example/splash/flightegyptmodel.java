package com.example.splash;

public class flightegyptmodel {
    public String airline;
    public String date;
    public String fighttime;
    public String from;
    public String price;


    public flightegyptmodel() {
    }

    public flightegyptmodel(String airline, String date, String fighttime, String from, String price ) {
        this.airline = airline;
        this.date = date;
        this.fighttime = fighttime;
        this.from = from;
        this.price = price;

    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getFighttime() {
        return fighttime;
    }

    public void setFighttime(String fighttime) {
        this.fighttime = fighttime;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }



}
