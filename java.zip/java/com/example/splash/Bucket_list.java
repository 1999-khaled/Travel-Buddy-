package com.example.splash;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Bucket_list extends AppCompatActivity {
TextView list;
EditText txt;
Button btn;
ProgressBar pbar;
FirebaseAuth fauth;
String userid;

private FirebaseFirestore db = FirebaseFirestore.getInstance();
private CollectionReference userref =db.collection("users");
private CollectionReference user=db.collection("users");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bucket_list);

        fauth=FirebaseAuth.getInstance();

        list=(TextView)findViewById(R.id.listtext);
        txt=(EditText)findViewById(R.id.list_int);
        btn=(Button)findViewById(R.id.ADD);

        pbar=(ProgressBar)findViewById(R.id.progressBar2);


     btn.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
          pbar.setVisibility(View.VISIBLE);
          loadlist(v);
          addlist(v);



         }
     });




    }

    public void addlist(View v){

        String listtxt= txt.getText().toString().trim();

        LIST listt =new LIST(listtxt);

        userref.add(listt).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                Toast.makeText(Bucket_list.this, "added successfully", Toast.LENGTH_SHORT).show();
                pbar.setVisibility(View.INVISIBLE);
            }
        });




    }

    public void loadlist(View v){

        userref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                String data="";

                    for(QueryDocumentSnapshot DocumentSnapshot:queryDocumentSnapshots){


                        LIST listtt=DocumentSnapshot.toObject(LIST.class);
                        String item=listtt.getList();

                        data+= item+ "\n\n";



                    }

                    list.setText(data);

            }
        });


    }

}