package com.example.splash;

public class egyptactivitymodel {

    public String aname;
    public String aimage;
    public String city;
    public String aprice;

    public egyptactivitymodel() {
    }

    public egyptactivitymodel(String aname, String aimage, String city, String aprice) {
        this.aname = aname;
        this.aimage = aimage;
        this.city = city;
        this.aprice = aprice;
    }

    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }

    public String getAimage() {
        return aimage;
    }

    public void setAimage(String aimage) {
        this.aimage = aimage;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAprice() {
        return aprice;
    }

    public void setAprice(String aprice) {
        this.aprice = aprice;
    }
}
