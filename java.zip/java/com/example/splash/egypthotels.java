package com.example.splash;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

public class egypthotels extends AppCompatActivity {
    private FirebaseFirestore db;
    FirebaseStorage mstorage;
    private RecyclerView mfirestorelist;
    private FirestoreRecyclerAdapter adapter3;
    private RecycleronClickListener3 listener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_egypthotels);
        db=FirebaseFirestore.getInstance();
        mfirestorelist=(RecyclerView)findViewById(R.id.egypthotels_list);
        setOnClickListener();

        Query query=db.collection("egypt_hotels");

        FirestoreRecyclerOptions<egypthotelsmodel> options = new FirestoreRecyclerOptions.Builder<egypthotelsmodel>().setQuery(query,egypthotelsmodel.class).build();

        adapter3 = new FirestoreRecyclerAdapter<egypthotelsmodel, egypthotelholder>(options) {

            @NonNull
            @Override
            public egypthotelholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.egypthotelsrow,parent,false);

                return new egypthotelholder(view);
            }
            @Override
            protected void onBindViewHolder(@NonNull egypthotelholder holder, int position, @NonNull egypthotelsmodel model) {
                holder.hname.setText(model.getHname());
                holder.hrate.setText(model.getHrate());
                holder.hprice.setText(model.getHprice());
                holder.haddress.setText(model.getHaddress());

                Picasso.get().load(Uri.parse(holder.himage1=model.getHimage1())).into(holder.himageview1);
                Picasso.get().load(Uri.parse(holder.himage2=model.getHimage2())).into(holder.himageview2);
                Picasso.get().load(Uri.parse(holder.himage3=model.getHimage3())).into(holder.himageview3);
                Picasso.get().load(Uri.parse(holder.himage4=model.getHimage4())).into(holder.himageview4);



            }
        };

        mfirestorelist.setHasFixedSize(true);
        mfirestorelist.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mfirestorelist.setAdapter(adapter3);

    }
    private void setOnClickListener() {

        listener= new  RecycleronClickListener3() {
            @Override
            public void onClickkkk(View v, int Position) {
                Toast.makeText(getApplicationContext(), "opening site to book", Toast.LENGTH_SHORT).show();
                String url = "https://www.booking.com/hotel/eg/the-location.html?aid=397645;label=bin859jc-1DCAEoggI46AdIM1gDaEOIAQGYATG4ARfIAQzYAQPoAQH4AQKIAgGoAgO4AqbvkoAGwAIB0gIkZTBlN2U2NDktZjQ1NS00NjYwLTlkY2QtOTg5NDg3NDNiY2Zk2AIE4AIB;sid=bf1e3104588b94674c683f027c06f6e8;checkin=2021-01-17;checkout=2021-01-18&";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }


        };


    }

    private class egypthotelholder extends  RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView hname;
        private TextView hrate;
        private TextView hprice;
        private TextView haddress;
        private ImageView himageview1;
        private ImageView himageview2;
        private ImageView himageview3;
        private ImageView himageview4;
        public   String himage1;
        public   String himage2;
        public   String himage3;
        public   String himage4;




        public egypthotelholder(@NonNull View itemView) {
            super(itemView);

            hname= itemView.findViewById(R.id.hname);
            haddress= itemView.findViewById(R.id.haddress);
            hrate= itemView.findViewById(R.id.hrate);
            hprice= itemView.findViewById(R.id.hprice);

            himageview1=itemView.findViewById(R.id.image1);
            himageview2=itemView.findViewById(R.id.image2);
            himageview3=itemView.findViewById(R.id.image3);
            himageview4=itemView.findViewById(R.id.image4);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {

            listener.onClickkkk(itemView,getAdapterPosition());
        }
    }


    public  interface RecycleronClickListener3{
        void onClickkkk(View v,int Position);


    }


    @Override
    public void onStart() {
        super.onStart();
        adapter3.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter3.stopListening();
    }

}