package com.example.splash;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.material.navigation.NavigationView;

public class Home_page extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    ImageButton domestic,abroad;
    String countries[]={"Egypt","Ecuador","France","Canada","China","Italy","Usa","UK","Indonesia","Greek","Japan"};
    AutoCompleteTextView actxt;
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        actxt=(AutoCompleteTextView)findViewById(R.id.country);
        adapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.support_simple_spinner_dropdown_item,countries);
        actxt.setAdapter(adapter);
        actxt.setThreshold(1);


      /*  Menu menu=navigationView.getMenu();
        menu.findItem(R.id.log_out).setVisible(false);
        menu.findItem(R.id.profile).setVisible(false);*/

        //navigationView.setCheckedItem(R.id.nav_home);
        domestic=(ImageButton)findViewById(R.id.domestic);
        abroad=(ImageButton)findViewById(R.id.abroadd);
        drawerLayout=(DrawerLayout)findViewById(R.id.tv);
        navigationView=(NavigationView)findViewById(R.id.nav);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            toolbar=(Toolbar)findViewById(R.id.toolbar);

        }




        domestic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x= actxt.getText().toString().trim();
                if(x.equals("Egypt")){
                    Intent i=new Intent(getApplicationContext(),dEgypt.class);
                    startActivity(i);

                }

            }
        });
        abroad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(getApplicationContext(),Abroad.class);
                startActivity(i);
            }
        });
        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){

            drawerLayout.closeDrawer(GravityCompat.START);

        }else {
            super.onBackPressed();
        }
    }



     @Override
   public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_home:
            break;
            case R.id.bucket_list:
                Intent i = new Intent(getApplicationContext(),Bucket_list.class);
                startActivity(i);
                break;
            case R.id.play_buddy:
                Intent ivv= new Intent(getApplicationContext(),Play_buddy.class);
                startActivity(ivv);
                break;
            case R.id.profile:
                Intent iii = new Intent(getApplicationContext(),Firstpage.class);
                startActivity(iii);
                break;
            case R.id.log_out:
                Intent iiii = new Intent(getApplicationContext(),login.class);
                startActivity(iiii);
                break;

            case R.id.share_us:
                openfbpage("104984278207252");
                Toast.makeText(this, "opening page", Toast.LENGTH_SHORT).show();
                break;

            case R.id.rate_us:
                Uri uri= Uri.parse("https://play.google.com/store/apps/details?id="+getApplicationContext().getPackageName());
                Intent iv=new Intent(Intent.ACTION_VIEW,uri);
                try {
                    startActivity(iv);
                    Toast.makeText(this, "Opening playstore", Toast.LENGTH_SHORT).show();
                }catch (Exception e){

                    Toast.makeText(this, "unable to open", Toast.LENGTH_SHORT).show();
                }

                    break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    private void openfbpage(String id){
        try {
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/"+ id));
            startActivity(i);
        }catch (ActivityNotFoundException e){
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/"+ id));
            startActivity(i);
        }

    }

}