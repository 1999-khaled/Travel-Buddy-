package com.example.splash;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Play_buddy extends AppCompatActivity {
CardView elevate,snow,alto,cross,chess,redhands,airhockey,billiards,spy,headsup,dice,spin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_buddy2);
        elevate=(CardView)findViewById(R.id.china);
        snow=(CardView)findViewById(R.id.france);
        alto=(CardView)findViewById(R.id.uk);
        cross=(CardView)findViewById(R.id.italy);
        chess=(CardView)findViewById(R.id.mexico);
        redhands=(CardView)findViewById(R.id.japan);
        airhockey=(CardView)findViewById(R.id.greek);
        billiards=(CardView)findViewById(R.id.indonesia);
        spy=(CardView)findViewById(R.id.spy);
        dice=(CardView)findViewById(R.id.rolldice);
        spin=(CardView)findViewById(R.id.spinbottle);
        spin=(CardView)findViewById(R.id.headsup);


        elevate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.Elevate");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        snow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.ChillySnow");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.yodo1.crossyroad");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        chess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.chess");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        airhockey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.mobirix.airhockey");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        alto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.noodlecake.altosodyssey");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        redhands.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.redhands.twoplayergames");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        spin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =getPackageManager().getLaunchIntentForPackage("com.example.sensorgame");
                if(i!=null){
                    startActivity(i);

                }else{
                    Toast.makeText(Play_buddy.this, "ERROR", Toast.LENGTH_SHORT).show();

                }
            }
        });
        dice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), dice.class);
                startActivity(i);
            }
        });


    }
}