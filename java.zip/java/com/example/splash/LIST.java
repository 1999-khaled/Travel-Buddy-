package com.example.splash;

public class LIST {

        String List;

        public LIST() {
        }

        public LIST(String list) {
            this.List = list;
        }

        public  String getList() {
            return List;
        }

        public void setList(String list) {
            List = list;
        }

}
