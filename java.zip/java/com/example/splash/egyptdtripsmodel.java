package com.example.splash;

public class egyptdtripsmodel {
    public String contact;
    public String dtimage1;
    public String dtimage2;
    public String dtimage3;
    public String dtimage4;
    public String no_of_days;
    public String place;
    public String transportation;
    public String price;


    public egyptdtripsmodel() {
    }

    public egyptdtripsmodel(String price,String contact, String dtimage1, String dtimage2, String dtimage3, String dtimage4, String no_of_days, String place, String transportation) {
        this.contact = contact;
        this.dtimage1 = dtimage1;
        this.dtimage2 = dtimage2;
        this.dtimage3 = dtimage3;
        this.dtimage4 = dtimage4;
        this.no_of_days = no_of_days;
        this.place = place;
        this.transportation = transportation;
        this.price=price;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDtimage1() {
        return dtimage1;
    }

    public void setDtimage1(String dtimage1) {
        this.dtimage1 = dtimage1;
    }

    public String getDtimage2() {
        return dtimage2;
    }

    public void setDtimage2(String dtimage2) {
        this.dtimage2 = dtimage2;
    }

    public String getDtimage3() {
        return dtimage3;
    }

    public void setDtimage3(String dtimage3) {
        this.dtimage3 = dtimage3;
    }

    public String getDtimage4() {
        return dtimage4;
    }

    public void setDtimage4(String dtimage4) {
        this.dtimage4 = dtimage4;
    }

    public String getNo_of_days() {
        return no_of_days;
    }

    public void setNo_of_days(String no_of_days) {
        this.no_of_days = no_of_days;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getTransportation() {
        return transportation;
    }

    public void setTransportation(String transportation) {
        this.transportation = transportation;
    }
}
