package com.example.splash;


public class tourguidemoddel {

        public String gname;
        public String gmeetingpoint;
        public String gprice;
        public String grate;
        public String gnumber;
        public String image;



        public tourguidemoddel() {
        }

        public tourguidemoddel(String gname, String gmeetingpoint, String gprice, String grate, String gnumber ,String image ) {
            this.gname = gname;
            this.gmeetingpoint = gmeetingpoint;
            this.gprice = gprice;
            this.grate = grate;
            this.gnumber = gnumber;
            this.image = image;



        }

        public String getName() {
            return gname;
        }

        public void setName(String name) {
            this.gname = gname;
        }

        public String getMeeting_point() {
            return gmeetingpoint;
        }

        public void setMeeting_point(String meeting_point) {
            this.gmeetingpoint = meeting_point;
        }

        public String getRate() {
            return grate;
        }

        public void setRate(String Rate) {
            this.grate = grate;
        }

        public String getNumber() {
            return gnumber;
        }

        public void setNumber(String Number) {
            this.gnumber = gnumber;
        }

        public String getPrice() {
            return gprice;
        }

        public void setPrice(String Price) {
            this.gprice = gprice;
        }

       public String getImage() { return image;}

        public void setImage(String image) { this.image = image; }



}
